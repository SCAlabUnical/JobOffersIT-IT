package dataManagement.fixedData;

import java.util.HashMap;
import java.util.List;

public class RequestedData {
    private List<String> languages = List.of(
            "Python",
            "Java",
            "JavaScript",
            "C#",
            "C",
            "C++",
            "PHP",
            "R",
            "Objective-c",
            "TypeScript",
            "Swift",
            "Kotlin",
            "Matlab",
            "Go",
            "VBA",
            "Ruby",
            "Rust",
            "Ada",
            "Scala",
            "Abap",
            "Lua",
            "Dart",
            "Perl",
            "Julia",
            "Cobol",
            "Groovy",
            "Haskell",
            "Delphi",
            "HTML",
            "CSS",
            "SQL",
            "JQuery",
            "UML"
    );
    private List<String> ide = List.of(
            "Visual Studio",
            "Eclipse",
            "pyCharm",
            "IntelliJ",
            "NetBeans",
            "Sublime Text",
            "Atom",
            "Xcode",
            "Code::Blocks",
            "Vim",
            "PhpStorm",
            "Xamarin",
            "Komodo",
            "geany",
            "Qt Creator",
            "Emacs",
            "JDeveloper",
            "JCreator",
            "Light Table",
            "MonoDevelop",
            "RAD",
            "SharpDevelop",
            "Aptana",
            "DrJava",
            "RubyMine"
    );
    private List<String> db = List.of(
            "Oracle",
            "MySql",
            "Access",
            "PostgreSQL",
            "MongoDB",
            "Firebase",
            "Splunk",
            "Elasticsearch",
            "Redis",
            "SQLite",
            "DB2",
            "MariaDB",
            "SAP",
            "DynamoDB",
            "FileMaker",
            "Solr",
            "Firebird",
            "Sybase",
            "Neo4j",
            "Ingres",
            "Hbase",
            "Riak",
            "CouchBase",
            "Informix",
            "Netezza",
            "CouchDB",
            "Redshift",
            "Cassandra",
            "Derby",
            "Hive",
            "Azure",
            "BigQuery",
            "ClickHouse",
            "Exasol",
            "Greenplum",
            //"H2",
            "IBM",
            "OpenEdge",
            "Phoenix",
            "Presto"

    );
    private List<String> framework = List.of(
            "Ruby",
            "Flutter",
            "Django",
            "Visual Studio",
            "Angular",
            "AngularJS",
            "METEOR",
            "Laravel",
            "Express",
            "Spring",
            "PLAY",
            "CodeIgniter",
            "JQuery",
            "React",
            "VueJS",
            "Flask",
            "Symfony",
            "Gatsby",
            "Drupal",
            "Lamp",
            "NET",
            "Spark"
    );

    private HashMap<String,String> languagesTypeMap;
    private HashMap<String,String> dbmsTypeMap;

    private  HashMap<String, Boolean> languagesMap ;
    private  HashMap<String, Boolean> frameworksMap ;
    private  HashMap<String, Boolean> ideMap;
    private  HashMap<String, Boolean> dbmsMap;



    public RequestedData(){
        languagesTypeMap = new HashMap<>();
        languagesMap = new HashMap<>();
        frameworksMap = new HashMap<>();
        ideMap = new HashMap<>();
        dbmsTypeMap = new HashMap<>();
        dbmsMap = new HashMap<>();
    }
    public void setLanguagesMap(){
        for (String l:
             this.languages) {
            this.languagesMap.put(l,true);
        }
    }
    public void setFrameworksMap(){
        for (String l:
                this.framework) {
            this.frameworksMap.put(l,true);
        }
    }
    public void setIdeMap(){
        for (String l:
                this.ide) {
            this.ideMap.put(l,true);
        }
    }
    public void setDbMap(){
        for (String l:
                this.db) {
            this.dbmsMap.put(l,true);
        }
    }
    public void setLanguagesTypeMap() {
        languagesTypeMap.put("Python", "Object-Oriented");
        languagesTypeMap.put("Java", "Object-Oriented");
        languagesTypeMap.put("JavaScript","Object-Oriented;Aspect-Oriented" );
        languagesTypeMap.put("C#", "Structured;Imperative;Object-Oriented;Functional;Event-Oriented");
        languagesTypeMap.put("C++", "Procedural;Functional;Object-Oriented"); //**
        languagesTypeMap.put("PHP", "Imperative;Functional;Object-Oriented;Procedural;Reflective"); //**
        languagesTypeMap.put("R", "Object-Oriented;Imperative;Functional;Procedural;Reflective");
        languagesTypeMap.put("Objective-c", "Object-Oriented");
        languagesTypeMap.put("Rust", "Functional;Imperative;Structured;Object-Oriented"); //**
        languagesTypeMap.put("TypeScript", "Scripting;Object-Oriented;Structured;Imperative"); //**
        languagesTypeMap.put("VBA", "Object-Oriented;"); //**
        languagesTypeMap.put("Ruby", "Object-Oriented");
        languagesTypeMap.put("Ada", "Procedural;Object-Oriented");  //**
        languagesTypeMap.put("Scala", "Object-Oriented;Functional");  //**
        languagesTypeMap.put("Lua", "Scripting;Imperative;Procedural;Object-Oriented;Functional");  //**
        languagesTypeMap.put("Perl", "Functional;Imperative;Object-Oriented;Reflective;Procedural"); //**
        languagesTypeMap.put("Cobol", "Procedural"); //**
        languagesTypeMap.put("Haskell", "Functional");
        languagesTypeMap.put("Delphi", "Object-Oriented"); //**
        languagesTypeMap.put("Swift", "Object-Oriented;Functional;Imperative");
        languagesTypeMap.put("Kotlin", "Object-Oriented");
        languagesTypeMap.put("Matlab", "Functional;Imperative;Procedural;Object-Oriented");
        languagesTypeMap.put("C", "Imperative;Procedural");
        languagesTypeMap.put("Go", "Imperative;Structured");
        languagesTypeMap.put("Abap", "Object-Oriented;Structured;Imperative");
        languagesTypeMap.put("Dart", "Object-Oriented;Functional;Imperative;Reflective");
        languagesTypeMap.put("Julia", "Functional;Procedural");
        languagesTypeMap.put("Groovy", "Object-Oriented;Imperative;Scripting");
        languagesTypeMap.put("HTML", "Markup");
        languagesTypeMap.put("CSS", "Style-Sheets");
        languagesTypeMap.put("UML", "Modelling;Procedural");
        languagesTypeMap.put("JQuery", "Scripting");
        languagesTypeMap.put("SQL", "Query");
    }

    public void setDbmsTypeMap() {
        dbmsTypeMap.put("Oracle", "Relational");
        dbmsTypeMap.put("MySql", "Relational");
        dbmsTypeMap.put("Access", "Relational");
        dbmsTypeMap.put("SQL", "Relational");
        dbmsTypeMap.put("PostgreSQL", "Relational");
        dbmsTypeMap.put("MongoDB","Document-Oriented");
        dbmsTypeMap.put("Firebase", "No-Sql");
        dbmsTypeMap.put("Splunk", "Document-Oriented");
        dbmsTypeMap.put("Elasticsearch", "No-Sql");
        dbmsTypeMap.put("Redis", "No-sql");
        dbmsTypeMap.put("SQLite", "Relational");
        dbmsTypeMap.put("DB2", "Relational");
        dbmsTypeMap.put("MariaDB", "Relational");
        dbmsTypeMap.put("SAP", "Relational");
        dbmsTypeMap.put("DynamoDB", "No-Sql");
        dbmsTypeMap.put("FileMaker", "Relational");
        dbmsTypeMap.put("Solr", "No-Sql");
        dbmsTypeMap.put("Firebird", "Relational");
        dbmsTypeMap.put("Sybase", "Relational");
        dbmsTypeMap.put("Neo4j", "No-Sql");
        dbmsTypeMap.put("Ingres", "Relational");
        dbmsTypeMap.put("Hbase", "No-Sql");
        dbmsTypeMap.put("Riak", "No-Sql");
        dbmsTypeMap.put("CouchBase", "No-Sql");
        dbmsTypeMap.put("Memcached", "");
        dbmsTypeMap.put("Informix", "Distributed-Memory-Caching-System");
        dbmsTypeMap.put("Netezza", "Relational");
        dbmsTypeMap.put("CouchDB", "Document-Oriented");
        dbmsTypeMap.put("Amazon RedShift", "");
        dbmsTypeMap.put("Redshift","Relational");
        dbmsTypeMap.put("Cassandra","No-Relational");
        dbmsTypeMap.put("Derby","Relational");
        dbmsTypeMap.put("Hive","Relational");
        dbmsTypeMap.put("Azure","Relational");
        dbmsTypeMap.put("BigQuery","Relational");
        dbmsTypeMap.put("ClickHouse","Column-Oriented");
        dbmsTypeMap.put("Exasol","Relational");
        dbmsTypeMap.put("Greenplum","Relational");
        dbmsTypeMap.put("H2","Relational");
        dbmsTypeMap.put("IBM","Relational");
        dbmsTypeMap.put("OpenEdge","Relational");
        dbmsTypeMap.put("Phoenix","Relational");
        dbmsTypeMap.put("Presto","Relational");
    }


    public List<String> getLanguages() {
        return languages;
    }
    public List<String> getIde() {
        return ide;
    }
    public List<String> getDb() {
        return db;
    }
    public List<String> getFramework() {
        return framework;
    }

    public HashMap<String, Boolean> getLanguagesMap() {
        return languagesMap;
    }
    public HashMap<String, String> getLanguagesTypeMap() {
        return languagesTypeMap;
    }
    public HashMap<String, Boolean> getFrameworksMap() {
        return frameworksMap;
    }
    public HashMap<String, Boolean> getIdeMap() {
        return ideMap;
    }
    public HashMap<String, String> getDbmsTypeMap() {
        return dbmsTypeMap;
    }
    public HashMap<String, Boolean> getDbmsMap() {
        return dbmsMap;
    }
}
