package dataManagement.fixedData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public final class InsertFixedData extends RequestedData {
    private Connection con ;

    private void getConnection(){
        Connection con = null;
        try{
            String urlDb = "jdbc:postgresql://localhost:5432/searchAndDownload";
            String user = "postgres";
            String password = "uni21db";
            System.out.println("Connecting to the selected database...");
            con = DriverManager.getConnection(urlDb, user, password);
            System.out.println("Connected database successfully...");
        }catch (SQLException sqlException){
            sqlException.getCause();
        }
        this.con=con;
    }

    public void starter() throws SQLException {
        setLanguagesTypeMap();
        setDbmsTypeMap();
        for (String language: getLanguages()){
            insertProgrammingLanguages(con,language,getLanguagesTypeMap().get(language));
        }
        for (String framework: getFramework()){
            insertFrameworks(con,framework);
        }
        for (String ide: getIde()){
            insertIdes(con,ide);
        }
        for (String dbms: getDb()){
            insertDbms(con,dbms, getDbmsTypeMap().get(dbms));
        }
    }

    private void insertProgrammingLanguages(Connection con,String language,String type) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO " +
                "programming_languages(programming_language,type)VALUES (?,?)");
        preparedStatement.setString(1, language);
        preparedStatement.setString(2, type);
        try {
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            System.out.println("DUPLICATE LINK");
        }
    }
    private void insertFrameworks(Connection con,String framework) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO " +
                "frameworks(framework)VALUES (?)");
        preparedStatement.setString(1, framework);
        try {
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            System.out.println("DUPLICATE LINK");
        }
    }
    private void insertIdes(Connection con,String ide) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO " +
                "ides(ide)VALUES (?)");
        preparedStatement.setString(1, ide);
        try {
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            System.out.println("DUPLICATE LINK");
        }
    }
    private void insertDbms(Connection con,String db,String type) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO " +
                "dbms(db, type)VALUES (?,?)");
        preparedStatement.setString(1, db);
        preparedStatement.setString(2, type);
        try {
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            System.out.println("DUPLICATE LINK");
        }
    }

    public static void main(String[] args) throws SQLException {
       InsertFixedData insertFixedData = new InsertFixedData();
       insertFixedData.getConnection();
       insertFixedData.starter();
    }
}
