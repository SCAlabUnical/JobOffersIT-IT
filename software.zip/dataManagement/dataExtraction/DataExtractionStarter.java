package dataManagement.dataExtraction;

import java.sql.*;

public final class DataExtractionStarter {
    public static void main(String[] args) throws SQLException {
        RandstadData randstadData = new RandstadData();
        ManpowerData manpowerData = new ManpowerData();
        AdeccoData adeccoData = new AdeccoData();
        adeccoData.starter();
        randstadData.starter();
        manpowerData.starter();

    }
}
