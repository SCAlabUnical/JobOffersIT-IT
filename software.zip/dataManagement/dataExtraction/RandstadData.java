package dataManagement.dataExtraction;

import dataManagement.fixedData.RequestedData;

import java.sql.*;
import java.util.StringTokenizer;

public final class RandstadData extends AbstractDataExtraction {
    private int CR = 0;
    private String date, location, category, contract, subCategory, requestedJob;
    private final RequestedData requestedData;
    private StringBuilder sbLanguages,sbFrameworks,sbIde,sbDbms;
    private String languagesData, frameworkData, dbmsData,ideData;


    public RandstadData() {
        requestedData = new RequestedData();
    }

    public String getRequestedJob(String html) {
        String title;
        String patternFrom = " <h1> <span id=\"js_jobTitle\">";
        String patternTo1 = "-";
        String patternTo2 = "</span>";
        int from = html.indexOf(patternFrom);
        int to1 = -1;
        int to2 = -1;
             to1 = from + html.substring(from).indexOf(patternTo1);
             to2 = from + html.substring(from).indexOf(patternTo2);
        //System.out.println ( to1 +"**"+ to2);
        if (to1 < to2) {
            title = html.substring(from + patternFrom.length(), to1);
        } else {
            title = html.substring(from + patternFrom.length(), to2);
        }
        return title.toUpperCase();
    }

    public String getDate(String html) {
        String date = "";
        if (html.contains("time datetime")) {
            int i = html.indexOf("<time datetime=\"") + 16;
            String txt = html.substring(i);
            int j = txt.indexOf("\">");
            String data = txt.substring(0, j);
            StringTokenizer stringTokenizer = new StringTokenizer(data, "-");
            StringBuilder modifyData = new StringBuilder();
            String yy, mm, dd;
            yy = stringTokenizer.nextToken();
            mm = stringTokenizer.nextToken();
            dd = stringTokenizer.nextToken();
            modifyData.append(dd).append("/").append(mm).append("/").append(yy);
            date = modifyData.toString();
        }
        return date;
    }

    public String getLocation(String html) {
        String location = "";
        if (html.contains("js_locationLabel")) {
            int i = html.indexOf("class=\"js_locationLabel\">") + 25;
            String txt = html.substring(i);
            int j1 = txt.indexOf(",");  //</
            int j2 = txt.indexOf("</");
            int j;
            j = Math.min(j2, j1);
            location = txt.substring(0, j).toUpperCase();
            if (location.contains("CITTA'METROPOLITANA DI")) {
                int from = location.indexOf("DI");
                location = location.substring(from + 3);
            }
        }
        return location;
    }

    public String getCategory(String html) {
        String category = "";
        if (html.contains("SectorLabel")) {
            int i = html.indexOf("SectorLabel\">") + 13;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            category = txt.substring(0, j).toUpperCase();
        }
        return category;
    }

    public String getSubCategory(String html) {
        String subCategory = "";
        if (html.contains("SubSectorLabel")) {
            int i = html.indexOf("SubSectorLabel\">") + 16;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            subCategory = txt.substring(0, j).toUpperCase();
        }
        return subCategory;
    }

    public String getContract(String html) {
        String contract = "";
        if (html.contains("js_jobType")) {
            int i = html.indexOf("\"js_jobType\">") + 13;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            contract = txt.substring(0, j).toUpperCase();
        }
        return contract;
    }

    public String getLanguagesData(String token) {
            for (String language : requestedData.getLanguages()) {
                if (token.equalsIgnoreCase(language) && requestedData.getLanguagesMap().get(language)) {
                    sbLanguages.append(language).append(" ; ");
                    requestedData.getLanguagesMap().put(language, false);
                    break;
                } else {
                    if (token.equalsIgnoreCase("Objective")) {
                        System.out.println("*");
                        String foundLanguage = "Objective-c";
                        sbLanguages.append(foundLanguage).append(" ; ");
                        requestedData.getLanguagesMap().put(foundLanguage, false);
                        break;
                    }
                }

            }
        if(sbLanguages.length()>0) {
            return sbLanguages.substring(0, sbLanguages.length() - 2);
        }
        return sbLanguages.toString();
    }

    public String getFrameworkData(String token, String jobSpecifics) {
            for (String framework :
                    requestedData.getFramework()) {
                if (token.equalsIgnoreCase(framework) && requestedData.getFrameworksMap().get(framework)) {
                    sbFrameworks.append(framework).append(" ; ");
                    requestedData.getFrameworksMap().put(framework, false);
                    break;
                }
            }

        if(sbFrameworks.length()>0) {
            return sbFrameworks.substring(0, sbFrameworks.length() - 2);
        }
        return sbFrameworks.toString();
    }

    public String getIdeData(String token) {
            for (String ide :
                    requestedData.getIde()) {
                if (token.equalsIgnoreCase(ide) && requestedData.getIdeMap().get(ide)) {
                    sbIde.append(ide).append(" ; ");
                    requestedData.getIdeMap().put(ide, false);
                    break;
                }
            }
        if(sbIde.length()>0) {
            return sbIde.substring(0, sbIde.length() - 2);
        }
        return sbIde.toString();
    }

    public String getDbData(String token) {
            for (String db :
                    requestedData.getDb()) {
                if (token.equalsIgnoreCase(db) && requestedData.getDbmsMap().get(db)) {
                    sbDbms.append(db).append(" ; ");
                    requestedData.getDbmsMap().put(db, false);
                    break;
                }
            }
        if(sbDbms.length()>0) {
            return sbDbms.substring(0, sbDbms.length() - 2);
        }
        return sbDbms.toString();
    }

    public void starter() throws SQLException {
        Connection con = getDbConnnection();
        Statement s = con.createStatement();
        String search = "SELECT * FROM job_offers";
        ResultSet rs = s.executeQuery(search);
        while (rs.next()) {
            String url = rs.getString("link");
            if (url.contains("randstad")) {
                setRequestedData();
                sbLanguages = new StringBuilder();
                sbFrameworks = new StringBuilder();
                sbIde = new StringBuilder();
                sbDbms = new StringBuilder();
                CR++;
                System.out.println("RANDSTAD\nLINK: " + url);
                String html = rs.getString("html");
                String pattern = "<div class=\"job-details-desc-wrapper-inner\">";
                int from = html.indexOf(pattern) + pattern.length();
                int to = html.substring(from).indexOf("</article>") + html.substring(0, from).length();
                String jobSpecifics = html.substring(from, to);

                setRandstadData(html);
                tokenize(jobSpecifics);

                if(insertData(con, url,languagesData,frameworkData,ideData, dbmsData)){
                    insertJobSpecifics(con,url,jobSpecifics);
                }
                setRequestedData();
            }
        }
        con.close();
        System.out.println("\nJOB OFFERS ANALYZED: " + CR);
    }

    private void insertJobSpecifics(Connection con,String url,String jobSpecifics) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement(
                "INSERT INTO "+ "job_specifics(link, specifics) "+ " VALUES (?,?)"
        );
        preparedStatement.setString(1,url);
        preparedStatement.setString(2,jobSpecifics);
        preparedStatement.executeUpdate();
    }


    private void tokenize(String jobSpecifics) {
        StringTokenizer st = new StringTokenizer(jobSpecifics, " /;,:.<>'-_()");
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            languagesData = getLanguagesData(token);
            frameworkData = getFrameworkData(token, jobSpecifics);
            ideData = getIdeData(token);
            dbmsData = getDbData(token);
        }
    }

    private boolean insertData(Connection con, String url, String languagesData, String frameworkData, String ideData, String dbmsData) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO " +
                "job_data(link,publication_date,job_location,job_category,job_sub_category,type_of_contract,requested ) " +
                "VALUES (?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
        preparedStatement.setString(1, url);
        preparedStatement.setString(2, date);
        preparedStatement.setString(3, location);
        preparedStatement.setString(4, category);
        preparedStatement.setString(5, subCategory);
        preparedStatement.setString(6, contract);
        preparedStatement.setString(7, requestedJob);
        try {
            preparedStatement.executeUpdate();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            while (rs.next()) {
                int id = rs.getInt("id");
                insertProgrammingLanguage(con, id, languagesData);
                insertFramework(con, id, frameworkData);
                insertIde(con, id, ideData);
                insertDbms(con, id, dbmsData);
            }
        } catch (Exception e) {
            System.out.println("DUPLICATE LINK");
            return false;
        }
        return true;

    }


    private void insertProgrammingLanguage(Connection con, int id, String languagesData) throws SQLException {
        StringTokenizer st = new StringTokenizer(languagesData, "; ");
        while (st.hasMoreTokens()) {
            String language = st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From programming_languages";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("programming_language");
                if (string.equalsIgnoreCase(language)) {
                    int languageId = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_language(job,language) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, languageId);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }

    private void insertFramework(Connection con, int id, String frameworkData) throws SQLException {
        StringTokenizer st = new StringTokenizer(frameworkData, "; ");
        while (st.hasMoreTokens()) {
            String framework= st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From frameworks";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("framework");
                if (string.equalsIgnoreCase(framework)) {
                    int frameworkId = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_framework(job,framework) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, frameworkId);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }

    private void insertDbms(Connection con, int id, String dbmsData) throws SQLException {
        StringTokenizer st = new StringTokenizer(dbmsData, "; ");
        while (st.hasMoreTokens()) {
            String dbms = st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From dbms";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("db");
                if (string.equalsIgnoreCase(dbms)) {
                    int dbmsIs = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_dbmbs(job,dbms) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, dbmsIs);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }
    private void insertIde(Connection con, int id, String ideData) throws SQLException {
        StringTokenizer st = new StringTokenizer(ideData, "; ");
        while (st.hasMoreTokens()) {
            String ide = st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From ides";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("ide");
                if (string.equalsIgnoreCase(ide)) {
                    int ideId = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_ide(job,ide) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, ideId);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }
    private void setRequestedData(){
        requestedData.setLanguagesMap();
        requestedData.setFrameworksMap();
        requestedData.setIdeMap();
        requestedData.setDbMap();
    }

    private void setRandstadData(String html){
        requestedJob = getRequestedJob(html);
        date=getDate(html);
        location=getLocation(html);
        category=getCategory(html);
        subCategory=getSubCategory(html);
        contract=getContract(html);
    }


}

