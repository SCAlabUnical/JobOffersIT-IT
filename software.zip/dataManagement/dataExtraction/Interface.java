package dataManagement.dataExtraction;

import java.sql.Connection;

public interface Interface {
     Connection getDbConnnection();
     String getDate(String html);
     String getLocation(String html);
     String getCategory(String html);
     String getContract(String html);
     String getRequestedJob(String html);
}
