package dataManagement.dataExtraction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public abstract class AbstractDataExtraction implements Interface {
    public Connection getDbConnnection() {
        Connection con = null;
        try {
            String urlDb = "jdbc:postgresql://localhost:5432/searchAndDownload";
            String user = "postgres";
            String password = "uni21db";
            System.out.println("Connecting to the selected database...");
            con = DriverManager.getConnection(urlDb, user, password);
            System.out.println("Connected database successfully...");
        }catch (SQLException sqlException){
            sqlException.getCause();
        }
        return con;
    }
    public abstract String getDate(String html);
    public abstract String getLocation(String html);
    public abstract String getCategory(String html);
    public abstract String getContract(String html);
    public abstract String getRequestedJob(String html);


}
