package dataManagement.dataExtraction;

import dataManagement.fixedData.RequestedData;

import java.sql.*;
import java.util.StringTokenizer;

public final class ManpowerData extends AbstractDataExtraction {
    private int CM = 0;
    private String date,location,category,contract,subCategory,requestedJob;
    private final RequestedData requestedData;
    private StringBuilder sbLanguages,sbFrameworks,sbIde,sbDbms;
    private String languagesData, frameworkData, dbmsData,ideData;

    public ManpowerData() {
        requestedData = new RequestedData();
    }


    public String getRequestedJob(String html) {
        String patternFrom = "title";
        String patternTo = "-";
        int from = html.indexOf(patternFrom) + 1;
        int to = from + html.substring(from).indexOf(patternTo);
        return html.substring(from + patternFrom.length(), to).toUpperCase();
    }

    public String getDate(String html) {
        String date = "";
        if (html.contains("Data pubblicazione")) {
            int i = html.indexOf("Data pubblicazione:</h3><span>") + 30;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            date = txt.substring(0, j).toUpperCase();
        }
        return date;
    }

    public String getLocation(String html) {
        String location = "";
        if (html.contains("Luogo di lavoro:")) {
            int i = html.indexOf("Luogo di lavoro:</h3><span><span><span>") + 39;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            location = txt.substring(0, j).toUpperCase();
            if (location.contains("CITTÀ METROPOLITANA DI")) {
                int from = location.indexOf("DI");
                location = location.substring(from + 3);
            }
        }
        return location;
    }

    public String getCategory(String html) {
        String category;
        String textAreaPattern = "<div class=\"text-box\"> \n" +
                "                <h3>Azienda</h3> <span>";
        int from = html.indexOf(textAreaPattern) + textAreaPattern.length();
        int to = html.substring(from).indexOf("</span> ") + html.substring(0, from).length();
        category = html.substring(from, to).toUpperCase();
        return category;
    }

    public String getContract(String html) {
        String contract = "";
        String availability = null;
        if (html.contains("Disponibilità")) {
            int i = html.indexOf("Disponibilità:</h3><span>") + 25;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            availability = txt.substring(0, j).toUpperCase();
        }
        if (html.contains("Tipologia")) {
            int i = html.indexOf("Tipologia:</h3><span>") + 21;
            String txt = html.substring(i);
            int j = txt.indexOf("</");
            contract = txt.substring(0, j).toUpperCase() + "-" + availability;
        }
        return contract;
    }

    public String getLanguagesData(String token) {
        boolean find = false;
        for (String language : requestedData.getLanguages()) {
            if (token.equalsIgnoreCase(language)) {
                if (requestedData.getLanguagesMap().get(language)) {
                    sbLanguages.append(language).append(" ; ");
                    requestedData.getLanguagesMap().put(language, false);
                    find = true;
                    break;
                }
            }
        }
        if (!find) {
            if (token.equalsIgnoreCase("Objective")) {
                String foundLanguage = "Objective-c";
                sbLanguages.append(foundLanguage).append(" ; ");
                requestedData.getLanguagesMap().put(foundLanguage, false);
            }
        }
        if(sbLanguages.length()>0) {
            return sbLanguages.substring(0, sbLanguages.length() - 2);
        }
        return sbLanguages.toString();
    }

    public String getFrameworkData(String token,String jobSpecifics) {
            for (String framework : requestedData.getFramework()) {
                if (token.equalsIgnoreCase(framework) && requestedData.getFrameworksMap().get(framework)) {
                    sbFrameworks.append(framework).append(" ; ");
                    requestedData.getFrameworksMap().put(framework, false);
                    break;
                }
            }
        if(sbFrameworks.length()>0) {
            return sbFrameworks.substring(0, sbFrameworks.length() - 2);
        }
        return sbFrameworks.toString();
    }

    public String getIdeData(String token) {
            for (String ide : requestedData.getIde()) {
                if (token.equalsIgnoreCase(ide) && requestedData.getIdeMap().get(ide)) {
                    sbIde.append(ide).append(" ; ");
                    requestedData.getIdeMap().put(ide, false);
                    break;
                }
            }
        if(sbIde.length()>0) {
            return sbIde.substring(0, sbIde.length() - 2);
        }
        return sbIde.toString();
    }

    public String getDbData(String token) {
            for (String db : requestedData.getDb()) {
                if (token.equalsIgnoreCase(db) && requestedData.getDbmsMap().get(db)) {
                    sbDbms.append(db).append(" ; ");
                    requestedData.getDbmsMap().put(db, false);
                    break;
                }
            }
        if(sbDbms.length()>0) {
            return sbDbms.substring(0, sbDbms.length() - 2);
        }
        return sbDbms.toString();
    }

    public void starter() throws SQLException {
        Connection con = getDbConnnection();
        Statement s = con.createStatement();
        String search = "SELECT * FROM job_offers";
        ResultSet rs = s.executeQuery(search);
        while (rs.next()) {
            String url = rs.getString("link");
            if (url.contains("manpower")) {
                setRequestedData();
                sbLanguages = new StringBuilder();
                sbFrameworks = new StringBuilder();
                sbIde = new StringBuilder();
                sbDbms = new StringBuilder();
                CM++;
                System.out.println("MANPOWER\nLINK: " + url);
                String html = rs.getString("html");
                String pattern = "<div class=\"text-box\"> \n" +
                        "                <h3>Descrizione</h3> <span>";
                int from = html.indexOf(pattern) + pattern.length();
                int to = html.substring(from).indexOf("</span>") + html.substring(0, from).length();
                String jobSpecifics = html.substring(from, to);

                setAdeccoData(html);
                tokenize(jobSpecifics);
                if(insertData(con, url, languagesData, frameworkData, ideData, dbmsData)){
                    insertJobSpecifics(con,url,jobSpecifics);
                }
                setRequestedData();
            }
        }
        con.close();
        System.out.println("\nJOB OFFERS ANALYZED: " + CM);
    }


    private void tokenize(String jobSpecifics) {
        StringTokenizer st = new StringTokenizer(jobSpecifics, " /;,:.<>'-_()");
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            languagesData = getLanguagesData(token);
            frameworkData = getFrameworkData(token, jobSpecifics);
            ideData = getIdeData(token);
            dbmsData = getDbData(token);
        }
    }

    private void insertJobSpecifics(Connection con,String url,String jobSpecifics) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement(
                "INSERT INTO "+ "job_specifics(link, specifics) "+ " VALUES (?,?)"
        );
        preparedStatement.setString(1,url);
        preparedStatement.setString(2,jobSpecifics);
        preparedStatement.executeUpdate();
    }

    private boolean insertData(Connection con, String url, String languagesData, String frameworkData, String ideData, String dbmsData) throws SQLException {
        PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO " +
                "job_data(link,publication_date,job_location,job_category,job_sub_category,type_of_contract,requested ) " +
                "VALUES (?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
        preparedStatement.setString(1, url);
        preparedStatement.setString(2, date);
        preparedStatement.setString(3, location);
        preparedStatement.setString(4, category);
        preparedStatement.setString(5, subCategory);
        preparedStatement.setString(6, contract);
        preparedStatement.setString(7, requestedJob);
        try {
            preparedStatement.executeUpdate();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            while (rs.next()) {
                int id = rs.getInt("id");
                insertProgrammingLanguage(con, id, languagesData);
                insertFramework(con, id, frameworkData);
                insertIde(con, id, ideData);
                insertDbms(con, id, dbmsData);
            }
        } catch (Exception e) {
            System.out.println("DUPLICATE LINK");
            return false;
        }
        return true;
    }


    private void insertProgrammingLanguage(Connection con, int id, String languagesData) throws SQLException {
        StringTokenizer st = new StringTokenizer(languagesData, "; ");
        while (st.hasMoreTokens()) {
            String language = st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From programming_languages";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("programming_language");
                if (string.equalsIgnoreCase(language)) {
                    int languageId = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_language(job,language) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, languageId);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }

    private void insertFramework(Connection con, int id, String frameworkData) throws SQLException {
        StringTokenizer st = new StringTokenizer(frameworkData, "; ");
        while (st.hasMoreTokens()) {
            String framework= st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From frameworks";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("framework");
                if (string.equalsIgnoreCase(framework)) {
                    int frameworkId = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_framework(job,framework) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, frameworkId);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }

    private void insertDbms(Connection con, int id, String dbmsData) throws SQLException {
        StringTokenizer st = new StringTokenizer(dbmsData, "; ");
        while (st.hasMoreTokens()) {
            String dbms = st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From dbms";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("db");
                if (string.equalsIgnoreCase(dbms)) {
                    int dbmsIs = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_dbmbs(job,dbms) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, dbmsIs);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }
    private void insertIde(Connection con, int id, String ideData) throws SQLException {
        StringTokenizer st = new StringTokenizer(ideData, "; ");
        while (st.hasMoreTokens()) {
            String ide = st.nextToken();
            Statement s = con.createStatement();
            String search ="SELECT * From ides";
            ResultSet rs = s.executeQuery(search);
            while (rs.next()) {
                String string = rs.getString("ide");
                if (string.equalsIgnoreCase(ide)) {
                    int ideId = rs.getInt("id");
                    PreparedStatement insertJobLanguage = con.prepareStatement("INSERT INTO " +
                            "r_job_ide(job,ide) " +
                            "VALUES (?,?)");
                    insertJobLanguage.setInt(1, id);
                    insertJobLanguage.setInt(2, ideId);
                    insertJobLanguage.executeUpdate();
                }
            }
        }
    }
    private void setRequestedData(){
        requestedData.setLanguagesMap();
        requestedData.setFrameworksMap();
        requestedData.setIdeMap();
        requestedData.setDbMap();
    }

    private void setAdeccoData(String html){
        requestedJob=getRequestedJob(html);
        date=getDate(html);
        location=getLocation(html);
        category=getCategory(html);
        //manpowerData.subCategory=manpowerData.getSubCategory(html);
        contract=getContract(html);
    }



}
