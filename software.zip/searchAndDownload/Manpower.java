package searchAndDownload;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public final class Manpower extends Abstract {
    /*
        it contains urls to the "found" job offers
    */
    private final LinkedList<String> jobOffersUrls = new LinkedList<>();
    /*
        it contains urls to pages that contains job offers
    */
    private final ArrayList<String> urlsPages = new ArrayList<>();
    private final int nMaxThread = Runtime.getRuntime().availableProcessors();
    private final String url;
    private final String site;

    //builder
    public Manpower(String url, String site) {
        this.url = url;
        this.site = site;
    }

    /*
        scraping web page from giving url, searching url to next pages
    */
    public int searchPages() {  //recursive method
        int nPages = 0;
        try {
            Document doc = Jsoup.connect(url).get();
            Elements elements = doc.getElementsByClass("no-result qtext-center");
            if (!(elements.isEmpty())) {
                return nPages;
            } else {
                urlsPages.add(url);
                nPages = 1;
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        try {
            int i = 2;
            System.out.println("\nSearching some links to the others pages from: " + url);
            while (true) {
                int index = url.indexOf('?');
                String subString = url.substring(0, index);
                String nextPage = subString + "/" + i + "?q_dist=30&q_rpp=10";
                Document page = Jsoup.connect(nextPage).get();
                Elements elements = page.getElementsByClass("no-result qtext-center");
                if (!(elements.isEmpty())) {
                    System.out.println(url + " not contains any links to the others pages.\n");
                    break;
                } else {
                    System.out.println("Link found: " + nextPage);
                    urlsPages.add(nextPage);
                    nPages++;
                    i++;
                }
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        if (nPages > 1) { //useless
            System.out.println("Found all links to the pages,found: " + nPages + " pages");
        } else {
            System.out.println("Found only one page.");
        }
        System.out.println("\n==========\n");

        return nPages;
    }

    public boolean threadStart(int nPages, String site) {
        int pagesXThread = nPages / nMaxThread;
        int nTheadNotUsed = nPages - (nMaxThread * pagesXThread);
        int nThreadUsed = nMaxThread - nTheadNotUsed;
        int pagesToVisit = nThreadUsed * pagesXThread;
        if (pagesToVisit < 0) {
            pagesToVisit *= -1;
        }
        ThreadScraper[] threads;
        if (nPages < nMaxThread) { //passa collezione ed indici
            threads = new ThreadScraper[nPages];
            for (int i = 0; i < nPages; i++) {
                int to = i + 1;
                threads[i] = new ThreadScraper(urlsPages, i, to, jobOffersUrls, site);
                threads[i].start();
            }
        } else if ((nPages % nMaxThread) == 0) {
            int tCounter = 0;
            threads = new ThreadScraper[nMaxThread];
            for (int i = 0; i < nPages; i += pagesXThread) {
                int to = i + pagesXThread;
                threads[tCounter] = new ThreadScraper(urlsPages, i, to, jobOffersUrls, site);
                threads[tCounter].start();
                tCounter++;
            }
        } else {
            int tCounter = 0;
            threads = new ThreadScraper[nMaxThread];
            for (int i = 0; i < pagesToVisit; i += pagesXThread) {
                int to;
                if (pagesXThread > 1) {
                    to = i + pagesXThread;
                } else {
                    to = i + 1;
                }
                threads[tCounter] = new ThreadScraper(urlsPages, i, to, jobOffersUrls, site);
                threads[tCounter].start();
                tCounter++;
            }
            int pagesVisited = pagesToVisit;
            int pagesNotVisited = nPages - pagesVisited;
            int newPagesXThread = pagesNotVisited / nTheadNotUsed;

            for (int i = pagesVisited; i < nPages; i += newPagesXThread) {
                int to = i + newPagesXThread;
                threads[tCounter] = new ThreadScraper(urlsPages, i, to, jobOffersUrls, site);
                threads[tCounter].start();
                tCounter++;
            }
        }
        for (ThreadScraper thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return jobOffersUrls.size() != 0;
    }

    public static void main(String[] args) {
        boolean searching = true;
        String site = "manpower";
        String urlFirstPage = "https://www.manpower.it";
        Scanner sc = new Scanner(System.in);
        while (searching) {
            System.out.println("Write the key-word to be searched on " + site + "\nWrite exit to interrupt the execution\nKey word: ");
            String keyWord = sc.nextLine().replaceAll("\\s", "-").trim();
            if (keyWord.equalsIgnoreCase("exit")) {
                sc.close();
                System.out.println("Bye");
                searching = false;
            } else {
                System.out.println("\n==========\n");
                String url = urlFirstPage + "/trova-lavoro/italia/" + keyWord + "?q_dist=30";
                System.out.println("Url: " + url);
                Manpower mWS = new Manpower(url, site);
                int nPages = mWS.searchPages();
                if (nPages > 0) {
                    if (mWS.threadStart(nPages, site)) {
                        mWS.printJobsOffersUrls(mWS.jobOffersUrls);
                        mWS.insertData(mWS.jobOffersUrls);
                    } else {
                        System.out.println("Not found job offers,\nplease try later,bye.");
                    }
                } else {
                    System.out.println("Given url incorrect");
                }
                System.out.println("\n==========\n");
            }
        }
    }
}