package searchAndDownload;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;


import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public final class Randstad extends Abstract {
/*
    it contains urls to the "found" job offers
*/
    private final LinkedList<String> jobOffersUrls = new LinkedList<>();
/*
    it contains urls to pages that contains job offers
*/
    private final ArrayList<String> urlsPages = new ArrayList<>();
    private final int nMaxThread = Runtime.getRuntime().availableProcessors();
    private final String url;
    private final String site;
    //builder
    public Randstad(String url, String site){
        this.url=url;
        this.site=site;
    }

/*
    scraping web page from giving url searching url to next pages
*/
    public int searchPages() {  //recursive method
        String titleFirstPage = null;
        int nPages = 0;
        try {
            Document docFirstPage = Jsoup.connect(url).get();
            titleFirstPage = Jsoup.connect(url).get().title();
            Elements elements = docFirstPage.getElementsByClass("nfc nfc-negative nfc-no-jobs-found has-bg-img-before");
            if(!(elements.isEmpty())){
                return nPages;
            }
            else{
                urlsPages.add(url);
                nPages = 1;
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        int i = 2;
        System.out.println("\nSearching some links to the others pages from: " + url);
        while (true) {
            String nextPage = url + "/page-" + i + "/"; //format url
            try {
                Document page = Jsoup.connect(nextPage).get();
                if (page.title().equals(titleFirstPage)) { //equals first page
                    System.out.println(url + " not contains any links to the others pages.\n");
                    break;
                }
                else{
                    System.out.println("Link found: " + nextPage);
                    urlsPages.add(nextPage);
                    nPages++;
                    i++;
                }
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
        }
        if(nPages>1){
            System.out.println("\nFound all links to the pages,found: "+nPages+" pages");
        } else {
            System.out.println("\nFound only one page.");
        }
        System.out.println("\n==========\n");
        return nPages;
    }

    public boolean threadStart(int nPages,String site){

        int pagesXThread = nPages / nMaxThread;
        int nTheadNotUsed = nPages - (nMaxThread*pagesXThread);
        int nThreadUsed = nMaxThread - nTheadNotUsed;
        int pagesToVisit = nThreadUsed * pagesXThread;

        if(pagesToVisit<0){pagesToVisit*=-1;}
        ThreadScraper[] threads;
        if(nPages < nMaxThread){
            threads = new ThreadScraper[nPages];
            for (int i = 0; i < nPages; i++) {
                int to = i+1;
                threads[i] = new ThreadScraper(urlsPages,i,to,jobOffersUrls,site);
                threads[i].start();
            }
        }
        else if ((nPages % nMaxThread) == 0) {
            int tCounter = 0;
            threads = new ThreadScraper[nMaxThread];
            for(int i = 0; i < nPages; i += pagesXThread){
                int to = i+pagesXThread;
                threads[tCounter] = new ThreadScraper(urlsPages,i,to,jobOffersUrls,site);
                threads[tCounter].start();
                tCounter++;
            }
        }
        else {
            int tCounter = 0;
            threads = new ThreadScraper[nMaxThread];
            for (int i = 0; i < pagesToVisit; i += pagesXThread) {
                int to;
                if (pagesXThread > 1) {
                    to = i + pagesXThread;
                } else {
                    to = i + 1;
                }
                threads[tCounter] = new ThreadScraper(urlsPages,i,to,jobOffersUrls,site);
                threads[tCounter].start();
                tCounter++;
            }
            int pagesVisited = pagesToVisit;
            int pagesNotVisited = nPages - pagesVisited;
            int newPagesXThread = pagesNotVisited / nTheadNotUsed;
            for (int i = pagesVisited; i < nPages; i += newPagesXThread) {
                int to = i+newPagesXThread;
                threads[tCounter] = new ThreadScraper(urlsPages,i,to,jobOffersUrls,site);
                threads[tCounter].start();
                tCounter++;
            }
        }
        for (ThreadScraper thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return jobOffersUrls.size() != 0;
    }

    public static void main(String[] args) {
        boolean searching = true;
        String site = "randstad";
        String urlFirstPage = "https://www.randstad.it/offerte-lavoro/q-";
        Scanner sc = new Scanner(System.in);
        while(searching) {
            System.out.println("Write the key-word to be searched on " + site + "\nWrite exit to interrupt the execution\nKey word: ");
            String keyWord = sc.nextLine().replaceAll("\\s","-").trim();
            if (keyWord.equalsIgnoreCase("exit")) {
                sc.close();
                System.out.println("Bye");
                searching = false;
            } else {
                System.out.println("\n==========\n");
                String url = urlFirstPage + keyWord;
                System.out.println("Url: "+url);
                Randstad rWS = new Randstad(url, site);
                int nPages = rWS.searchPages();
                if(nPages>0) {
                    if (rWS.threadStart(nPages, site)) {
                        rWS.printJobsOffersUrls(rWS.jobOffersUrls);
                        rWS.insertData(rWS.jobOffersUrls);
                    } else{
                        System.out.println("Not found job offers,\nplease try later,bye.");
                    }
                } else{
                    System.out.println("Given url incorrect");
                }
                System.out.println("\n==========\n");
            }
        }
    }
}


