package searchAndDownload;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.LinkedList;

public final class ThreadScraper extends Thread {
    private final String site;
    private final ArrayList<String> urlsPages;
    private final LinkedList<String> jobOffersUrls;
    private final int from;
    private final int to;

    public ThreadScraper(ArrayList<String> urlsPages, int from, int to , LinkedList<String> jobOffersUrls, String site) {
        this.from = from;
        this.to = to;
        this.urlsPages = urlsPages;
        this.jobOffersUrls = jobOffersUrls;
        this.site = site;
    }

    @Override
    public void run() {
        for (int i=from;i<to;i++) {
            searchJobOffers(urlsPages.get(i),jobOffersUrls,site);
        }
    }

/*
    scraping page giving url, searching for links to the job offers to add into collection
*/
    private void searchJobOffers(String url, LinkedList<String> jobOffersUrls, String site) {
        try {
            Document doc = Jsoup.connect(url).get();
            System.out.println("Downloading data from: " +url+" (operated by: "+this.getName()+")\n");
            switch (site) {
                case "randstad":
                    Elements links = doc.select("a[href]");
                    String button = "scopri di più";
                    for (Element link : links) {
                        String linkHref = link.attr("abs:href");
                        String linkTxt = link.text();
                        if (linkTxt.equals(button)) {
                            jobOffersUrls.add(linkHref);
                        }
                    }break;
                case "manpower":
                    Elements saveButtons = doc.getElementsByClass("save-ad");
                    for (Element element : saveButtons) {
                        String onclick = element.attr("onclick");
                        int pos = onclick.indexOf("http");
                        String offer = onclick.substring(pos, onclick.length() - 2);
                        jobOffersUrls.add(offer);
                    }break;
                case "adecco":
                    Elements viewOffers = doc.getElementsByClass("btn btn-sm btn-success pull-right");
                    for (Element e : viewOffers) {
                        String linkHref = e.attr("abs:href");
                        jobOffersUrls.add(linkHref);
                    }break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}