package searchAndDownload;

import org.jsoup.Jsoup;
import java.io.IOException;
import java.sql.*;

import java.util.LinkedList;
import java.util.ListIterator;

public abstract class Abstract implements Interface {
    private int counter = 0;
    protected final String urlDb = "jdbc:postgresql://localhost:5432/searchAndDownload";
    protected final String user = "postgres";
    protected final String password = "uni21db";

    public abstract int searchPages();

    public abstract boolean threadStart(int nPages,String site);

/*
    print all jobs offers found from scraping
*/
    public void printJobsOffersUrls(LinkedList<String> jobOffersUrls){
        for (String jobOffersUrl : jobOffersUrls) {
            System.out.println(jobOffersUrl);
        }
        System.out.println("\nEnd of job-offers Urls");
        System.out.println("Found: "+jobOffersUrls.size()+" job offers.");
        System.out.println("\n==========\n");
    }

/*
    insert (link,html) in db
*/
    public void insertData(LinkedList<String> jobOffersUrls){
        try {
            boolean contained = false;
            ListIterator<String> lit = jobOffersUrls.listIterator();
            Connection con = getDbConnection(urlDb,user,password);
            Statement s = con.createStatement();
            String search = "SELECT link FROM job_offers";
            while (lit.hasNext()) {
                String linkFound = lit.next();
                ResultSet rs = s.executeQuery(search);
                while (rs.next()) {
                    if (rs.getString("link").equals(linkFound)){
                        contained = true;
                        break;
                    }
                }//while
                if(contained){
                    contained = false;
                }
                else {
                    insertData(con,linkFound);
                    counter++;
                }
                rs.close();
            }
            printInfo();
            con.close();
        } catch (SQLException e) {
            e.getCause();
        }
    }

    private void insertData(Connection con,String linkFound)  {
        try {
            String pageContent = Jsoup.connect(linkFound).get().outerHtml();
            String insert = "INSERT INTO job_offers(link,html) " + "VALUES(?,?)";
            PreparedStatement pstm = con.prepareStatement(insert);
            pstm.setString(1, linkFound);
            pstm.setString(2, pageContent);
            pstm.executeUpdate();
        }catch (SQLException | IOException ioException){
            ioException.printStackTrace();
        }
    }

    private void printInfo(){
        if(counter > 1) {
            System.out.println("Insert " + counter + " job offers");
        }else if(counter == 1){
            System.out.println("Insert only one job offer");
        }else{
            System.out.println("No posting of job offers");
        }
    }

    private Connection getDbConnection (String urlDb,String user,String password){
        System.out.println("Connecting to the selected database...");
        Connection con = null;
        try {
            con = DriverManager.getConnection(urlDb,user,password);
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        System.out.println("Connected database successfully...");
        return con;
    }
}
