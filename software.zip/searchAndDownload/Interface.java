package searchAndDownload;

import java.util.LinkedList;

public interface Interface {
    int searchPages();
    boolean threadStart(int nPages,String site);
    void printJobsOffersUrls(LinkedList<String> jobOffersUrls);
    void insertData (LinkedList<String> jobOffersUrls);
}
